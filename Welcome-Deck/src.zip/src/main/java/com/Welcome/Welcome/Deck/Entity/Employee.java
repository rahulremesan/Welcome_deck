package com.Welcome.Welcome.Deck.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private  String name;
    private String email;
    private  String contactMobile;
    private String contactEmail;
    private String hometown;
    private String educationQualification;
    private String experience;
    private String hobbies;
    private String coreSkill;
    private String favouriteQuote;
    private String anotherProfession;
    private String profilePicturePath;
    private int assignedIbuId;
}
