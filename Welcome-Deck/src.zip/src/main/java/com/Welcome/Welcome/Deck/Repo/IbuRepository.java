package com.Welcome.Welcome.Deck.Repo;

import com.Welcome.Welcome.Deck.Entity.Ibu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IbuRepository extends JpaRepository<Ibu, Integer> {
}
