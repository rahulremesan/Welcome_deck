package com.Welcome.Welcome.Deck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelcomeDeckApplicationTests {

	@Test
	void contextLoads() {
	}

}
